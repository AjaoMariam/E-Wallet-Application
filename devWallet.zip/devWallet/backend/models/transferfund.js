const Sequelize = require('sequelize')
const sequelize = require('../config/connections.js')
const transferfund = sequelize.define('transferfund',{
    transferfundid:{
        type:Sequelize.UUID,
        defaultValue:Sequelize.UUIDV4,
        allowNull:false,
        primaryKey:true
    },
    Amounttransfer:{
        type:Sequelize.DOUBLE,
        allowNull:false
    },
    custid:{
        type:Sequelize.UUID,
        defaultValue:Sequelize.UUIDV4,
    }
  
})

const transferFund = async (walletData) => {
    const sender = walletData.user;
    const amount = walletData.amount;
    const password = walletData.password;
  
    let recipient;
  
    if (!recipient) {
      return Promise.reject({
        message: "Recipient not found",
        success: false,
      });
    }
  
    const senderWallet = await db("wallets").where("user_id", sender.id).first();
  
    if (senderWallet.balance < amount) {
      return Promise.reject({ message: "Insufficient Fund", success: false });
    }
  
    const match = await bcrypt.compare(password, senderWallet.password);
  
    if (!match) {
      return Promise.reject({
        message: "Incorrect Password",
        success: false,
      });
    }
  
    const generatedTransactionReference = randomstring.generate({
      length: 10,
      charset: "alphanumeric",
      capitalization: "uppercase",
    });
  
    const generatedTransactionCode = randomstring.generate({
      length: 7,
      charset: "numeric",
    });
  
    await db("wallets").where("user_id", sender.id).decrement("balance", amount);
  
    await db("transactions").insert({
      user_id: sender.id,
      transaction_code: generatedTransactionCode,
      transaction_reference: `PID-${generatedTransactionReference}`,
      amount: amount,
      description: "Fund Transfer",
      status: "successful",
      is_inflow: false,
    });
  
    await db("wallets")
      .where("user_id", recipient.id)
      .increment("balance", amount);
  
    await db("transactions").insert({
      user_id: recipient.id,
      transaction_code: generatedTransactionCode,
      transaction_reference: `PID-${generatedTransactionReference}`,
      amount: amount,
      description: "Fund Transfer",
      status: "successful",
      is_inflow: true,
    });
  };

module.exports = {transferfund}