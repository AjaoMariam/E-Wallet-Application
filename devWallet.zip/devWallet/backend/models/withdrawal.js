const Sequelize = require('sequelize')
const sequelize = require('../config/connections.js')
const withdrawal = sequelize.define('withdrawal',{
    withdrawalid:{
        type:Sequelize.UUID,
        defaultValue:Sequelize.UUIDV4,
        allowNull:false,
        primaryKey:true
    },
    Amountwithdraw:{
        type:Sequelize.DOUBLE,
        allowNull:false
    },
    custid:{
        type:Sequelize.UUID,
        defaultValue:Sequelize.UUIDV4,
    }
  
})
const withdrawFund = async (walletData) => {
    const user = walletData.user;
    const amount = walletData.amount;
    const password = walletData.password;
  
    const userWallet = await db("wallets").where("user_id", user.id).first();
  
    if (userWallet.balance < amount) {
      return Promise.reject({ message: "Insufficient Fund", success: false });
    }
  
  
    const match = await bcrypt.compare(password, userWallet.password);
  
    if (!match) {
      return Promise.reject({
        message: "Incorrect Password",
        success: false,
      });
    }
  
    const payment = await withdrawPayment(amount);
  
    const amountToDeduct = payment.amount + payment.fee;
  
    await db("wallets")
      .where("user_id", user.id)
      .decrement("balance", amountToDeduct);
  
    await db("transactions").insert({
      user_id: user.id,
      transaction_code: payment.id,
      transaction_reference: payment.reference,
      amount: amountToDeduct,
      description: "Fund Withdrawal",
      status: "successful",
      is_inflow: false,
    });
  };
  
  
   const getWalletBalance = async (walletData) => {
    const user = walletData.user;
    const wallet = await db("wallets").where("user_id", user.id).first();
  
    return wallet;
  };
  
module.exports = {withdrawal}
